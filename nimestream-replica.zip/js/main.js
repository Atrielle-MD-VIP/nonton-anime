// Main JavaScript for NIMESTREAM

document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('light-theme');
            const icon = this.querySelector('i');
            if (document.body.classList.contains('light-theme')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
            }
        });
    }

    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    const searchBtn = document.querySelector('.search-btn');

    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', function() {
            const query = searchInput.value.trim();
            if (query) {
                alert('Searching for: ' + query);
                // In real implementation: window.location.href = '/search?q=' + encodeURIComponent(query);
            }
        });

        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchBtn.click();
            }
        });
    }

    // Bottom Navigation Active State
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            // Remove active from all
            navItems.forEach(nav => nav.classList.remove('active'));
            // Add active to clicked
            this.classList.add('active');
        });
    });

    // Anime Card Click Handler
    const animeCards = document.querySelectorAll('.anime-card');
    animeCards.forEach(card => {
        card.addEventListener('click', function() {
            const title = this.querySelector('.card-title').textContent;
            console.log('Opening:', title);
            // Navigate to detail page
            // window.location.href = 'detail.html?id=' + encodeURIComponent(title);
        });
    });

    // Server Button Selection
    const serverBtns = document.querySelectorAll('.server-btn');
    serverBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active from all
            serverBtns.forEach(b => b.classList.remove('active'));
            // Add active to clicked
            this.classList.add('active');

            const server = this.dataset.server;
            console.log('Switching to server:', server);

            // In real implementation, switch video source
            switchServer(server);
        });
    });
});

// Navigate to detail page
function goToDetail(animeId) {
    console.log('Navigating to anime:', animeId);
    window.location.href = 'detail.html?id=' + animeId;
}

// Switch video server
function switchServer(serverName) {
    const videoSources = {
        'blogspot': 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        'premium720': 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        'nakama480': 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        'nakama720': 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4'
    };

    const video = document.getElementById('mainVideo');
    if (video && videoSources[serverName]) {
        const currentTime = video.currentTime;
        const wasPlaying = !video.paused;

        video.src = videoSources[serverName];
        video.load();

        video.addEventListener('loadedmetadata', function() {
            video.currentTime = currentTime;
            if (wasPlaying) {
                video.play();
            }
        }, { once: true });
    }
}

// Format time helper
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';

    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return minutes + ':' + (secs < 10 ? '0' : '') + secs;
}

// Debounce helper
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle helper
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Lazy loading for images
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Handle offline/online status
window.addEventListener('online', () => {
    console.log('Connection restored');
    document.body.classList.remove('offline');
});

window.addEventListener('offline', () => {
    console.log('Connection lost');
    document.body.classList.add('offline');
});

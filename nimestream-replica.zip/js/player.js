// Custom Video Player JavaScript for NIMESTREAM

document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('mainVideo');
    const videoContainer = document.getElementById('videoContainer');
    const playPauseBtn = document.getElementById('playPauseBtn');
    const playIcon = document.getElementById('playIcon');
    const progressContainer = document.getElementById('progressContainer');
    const progressBar = document.getElementById('progressBar');
    const progressFilled = document.getElementById('progressFilled');
    const currentTimeEl = document.getElementById('currentTime');
    const durationEl = document.getElementById('duration');
    const volumeBtn = document.getElementById('volumeBtn');
    const volumeIcon = document.getElementById('volumeIcon');
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    const fullscreenIcon = document.getElementById('fullscreenIcon');
    const centerPlay = document.getElementById('centerPlay');
    const videoControls = document.getElementById('videoControls');

    if (!video) return;

    let isPlaying = false;
    let isMuted = true; // Start muted like in screenshot
    let isFullscreen = false;
    let controlsTimeout;

    // Initialize
    video.muted = true;
    updateVolumeIcon();

    // Play/Pause Toggle
    function togglePlay() {
        if (video.paused) {
            video.play();
            isPlaying = true;
            playIcon.classList.remove('fa-play');
            playIcon.classList.add('fa-pause');
            centerPlay.style.display = 'none';
        } else {
            video.pause();
            isPlaying = false;
            playIcon.classList.remove('fa-pause');
            playIcon.classList.add('fa-play');
            centerPlay.style.display = 'flex';
        }
    }

    playPauseBtn.addEventListener('click', togglePlay);

    if (centerPlay) {
        centerPlay.addEventListener('click', togglePlay);
    }

    video.addEventListener('click', togglePlay);

    // Update Progress Bar
    function updateProgress() {
        const percent = (video.currentTime / video.duration) * 100;
        progressFilled.style.width = percent + '%';
        currentTimeEl.textContent = formatTime(video.currentTime);

        if (!isNaN(video.duration)) {
            durationEl.textContent = formatTime(video.duration);
        }
    }

    video.addEventListener('timeupdate', updateProgress);

    // Click on progress bar to seek
    progressContainer.addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        const pos = (e.clientX - rect.left) / rect.width;
        video.currentTime = pos * video.duration;
    });

    // Drag to seek
    let isDragging = false;

    progressContainer.addEventListener('mousedown', () => isDragging = true);
    document.addEventListener('mouseup', () => isDragging = false);
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const rect = progressContainer.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        video.currentTime = pos * video.duration;
    });

    // Volume Control
    function toggleMute() {
        video.muted = !video.muted;
        isMuted = video.muted;
        updateVolumeIcon();
    }

    function updateVolumeIcon() {
        if (video.muted || video.volume === 0) {
            volumeIcon.classList.remove('fa-volume-up', 'fa-volume-down');
            volumeIcon.classList.add('fa-volume-mute');
        } else if (video.volume < 0.5) {
            volumeIcon.classList.remove('fa-volume-up', 'fa-volume-mute');
            volumeIcon.classList.add('fa-volume-down');
        } else {
            volumeIcon.classList.remove('fa-volume-down', 'fa-volume-mute');
            volumeIcon.classList.add('fa-volume-up');
        }
    }

    volumeBtn.addEventListener('click', toggleMute);

    // Fullscreen
    function toggleFullscreen() {
        if (!document.fullscreenElement) {
            if (videoContainer.requestFullscreen) {
                videoContainer.requestFullscreen();
            } else if (videoContainer.webkitRequestFullscreen) {
                videoContainer.webkitRequestFullscreen();
            } else if (videoContainer.msRequestFullscreen) {
                videoContainer.msRequestFullscreen();
            }
            isFullscreen = true;
            fullscreenIcon.classList.remove('fa-expand');
            fullscreenIcon.classList.add('fa-compress');
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            } else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }
            isFullscreen = false;
            fullscreenIcon.classList.remove('fa-compress');
            fullscreenIcon.classList.add('fa-expand');
        }
    }

    fullscreenBtn.addEventListener('click', toggleFullscreen);

    // Handle fullscreen change events
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    function handleFullscreenChange() {
        if (!document.fullscreenElement && !document.webkitFullscreenElement && 
            !document.mozFullScreenElement && !document.msFullscreenElement) {
            isFullscreen = false;
            fullscreenIcon.classList.remove('fa-compress');
            fullscreenIcon.classList.add('fa-expand');
        } else {
            isFullscreen = true;
            fullscreenIcon.classList.remove('fa-expand');
            fullscreenIcon.classList.add('fa-compress');
        }
    }

    // Auto-hide controls
    function showControls() {
        videoControls.style.opacity = '1';
        clearTimeout(controlsTimeout);
        if (isPlaying) {
            controlsTimeout = setTimeout(() => {
                videoControls.style.opacity = '0';
            }, 3000);
        }
    }

    videoContainer.addEventListener('mousemove', showControls);
    videoContainer.addEventListener('click', showControls);

    // Keyboard Controls
    document.addEventListener('keydown', function(e) {
        // Only work when video is in viewport
        const rect = video.getBoundingClientRect();
        if (rect.bottom < 0 || rect.top > window.innerHeight) return;

        switch(e.code) {
            case 'Space':
                e.preventDefault();
                togglePlay();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                video.currentTime = Math.max(0, video.currentTime - 5);
                break;
            case 'ArrowRight':
                e.preventDefault();
                video.currentTime = Math.min(video.duration, video.currentTime + 5);
                break;
            case 'ArrowUp':
                e.preventDefault();
                video.volume = Math.min(1, video.volume + 0.1);
                if (video.muted) video.muted = false;
                updateVolumeIcon();
                break;
            case 'ArrowDown':
                e.preventDefault();
                video.volume = Math.max(0, video.volume - 0.1);
                updateVolumeIcon();
                break;
            case 'KeyM':
                e.preventDefault();
                toggleMute();
                break;
            case 'KeyF':
                e.preventDefault();
                toggleFullscreen();
                break;
        }
    });

    // Format time helper
    function formatTime(seconds) {
        if (isNaN(seconds)) return '0:00';
        const minutes = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }

    // Video loaded metadata
    video.addEventListener('loadedmetadata', function() {
        durationEl.textContent = formatTime(video.duration);
    });

    // Video ended
    video.addEventListener('ended', function() {
        isPlaying = false;
        playIcon.classList.remove('fa-pause');
        playIcon.classList.add('fa-play');
        centerPlay.style.display = 'flex';
        videoControls.style.opacity = '1';
    });

    // Buffering indicator
    video.addEventListener('waiting', function() {
        videoContainer.classList.add('buffering');
    });

    video.addEventListener('playing', function() {
        videoContainer.classList.remove('buffering');
    });

    // Picture in Picture (optional)
    const settingsBtn = document.getElementById('settingsBtn');
    if (settingsBtn && 'pictureInPictureEnabled' in document) {
        settingsBtn.addEventListener('click', async function() {
            try {
                if (document.pictureInPictureElement) {
                    await document.exitPictureInPicture();
                } else {
                    await video.requestPictureInPicture();
                }
            } catch (err) {
                console.log('PiP error:', err);
            }
        });
    }

    // Double click to fullscreen
    video.addEventListener('dblclick', toggleFullscreen);

    // Prevent context menu on video
    video.addEventListener('contextmenu', (e) => e.preventDefault());

    console.log('🎬 NIMESTREAM Player initialized');
});

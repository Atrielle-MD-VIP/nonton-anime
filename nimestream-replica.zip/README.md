# 🎬 NIMESTREAM - Anime Streaming Website Replica

Replika lengkap website streaming anime berdasarkan screenshot asli dengan fitur lengkap.

## 📁 Struktur File

```
nimestream-replica/
├── index.html          # Homepage dengan hero section & kategori
├── detail.html         # Halaman detail anime
├── watch.html          # Halaman video player
├── css/
│   └── style.css       # Styling lengkap (dark mode, responsive)
├── js/
│   ├── main.js         # Fungsi utama & navigasi
│   └── player.js       # Custom video player controls
└── README.md
```

## ✨ Fitur yang Tersedia

### 1. Homepage (index.html)
- ✅ Header dengan search box dan theme toggle
- ✅ Hero section dengan featured anime
- ✅ Kategori "Action Hits" & "Romance & Drama"
- ✅ Anime cards dengan hover effects
- ✅ Bottom navigation (Home, Anime, Recent, Favorite, Developer)

### 2. Detail Page (detail.html)
- ✅ Informasi lengkap anime (judul, status, rating, studio)
- ✅ Poster dengan rating overlay
- ✅ Tombol "Nonton" & "Terbaru"
- ✅ Metadata (Studio, Total EPS, Durasi)
- ✅ Daftar episode

### 3. Watch Page (watch.html)
- ✅ Custom video player dengan controls
- ✅ Watermark (Download di WWW.SAMEHADAKU.TV)
- ✅ Subtitle watermark (Penerjemah: Kly)
- ✅ Progress bar dengan seek functionality
- ✅ Play/Pause toggle
- ✅ Volume control (mute/unmute)
- ✅ Fullscreen mode
- ✅ Pilihan server (Blogspot, Premium 720p, Nakama 480p/720p)
- ✅ Keyboard shortcuts (Space, Arrow keys, M, F)

## 🎮 Keyboard Shortcuts (Watch Page)

| Key | Fungsi |
|-----|--------|
| `Space` | Play/Pause |
| `←` | Rewind 5 detik |
| `→` | Forward 5 detik |
| `↑` | Volume up |
| `↓` | Volume down |
| `M` | Mute/Unmute |
| `F` | Fullscreen toggle |
| `Double Click` | Toggle fullscreen |

## 🎨 Desain

- **Dark Theme**: Background #0a0a0a, card #1a1a1a
- **Accent Color**: Blue gradient (#3b82f6)
- **Font**: Inter (Google Fonts)
- **Icons**: Font Awesome 6
- **Responsive**: Mobile-first design

## 🚀 Cara Menggunakan

1. Buka `index.html` di browser
2. Klik anime card untuk ke detail page
3. Klik "Nonton" untuk ke watch page
4. Di watch page:
   - Klik video atau tombol play untuk memulai
   - Klik progress bar untuk seek
   - Pilih server berbeda di bawah video
   - Gunakan keyboard shortcuts

## 🛠️ Teknologi

- HTML5 Semantic
- CSS3 (Grid, Flexbox, Custom Properties)
- Vanilla JavaScript (ES6+)
- HTML5 Video API
- Fullscreen API
- Picture-in-Picture API

## 📱 Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## ⚠️ Catatan

- Video menggunakan sample dari Google Storage
- Images menggunakan placeholder dari TMDB API
- Avatar menggunakan DiceBear API
- Untuk production, ganti dengan asset asli

---

**Dibuat dengan ❤️ sebagai replika edukasional**
